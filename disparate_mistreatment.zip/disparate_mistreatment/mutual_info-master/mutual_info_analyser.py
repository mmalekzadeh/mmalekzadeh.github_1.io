import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as color

from sklearn import preprocessing
from sklearn.metrics import mutual_info_score, normalized_mutual_info_score


class MutualInfoAnalyser(object):

    def __init__(self, normalized=True):
        """
        An object for exploring mutual information
        :param normalized:
        :param n_bins:
        """
        if normalized:
            self.normalized = True
            self.mi_func = normalized_mutual_info_score
        else:
            self.normalized = False
            self.mi_func = mutual_info_score

    def add_dataframe(self, df, columns=None):
        """
        Add a pandas dataframe
        :param df:
        :param columns:
        :return:
        """
        if isinstance(df, np.ndarray):
            df = pd.DataFrame(df)
        self.df = df
        if columns is not None:
            self.df.columns = columns

    def discretize_dataframe(self, n_bins=5):
        """
        'Discretize' the dataframe.
        Categorical variables encoded as strings are converted to numeric labels.
        Numeric variables are binned if the number of unique values is > n_bins, \
        else they are left as is. In the case that values are not binned they should not be floats.
        :param n_bins:
        :return:
        """
        n_columns = self.df.shape[1]
        for c in range(n_columns):
            series = self.df.iloc[:, c]
            is_numeric = False if isinstance(series[0], str) else True
            if is_numeric:
                n_unique = np.unique(series).size
                if n_unique > n_bins:
                    series = pd.qcut(series, n_bins, labels=range(n_bins))
                else:
                    assert not isinstance(series[0], (float, np.floating)), 'Floating point attribute found'
                    pass
            else:
                label_encoder = preprocessing.LabelEncoder()
                series = label_encoder.fit_transform(series)
            self.df.iloc[:, c] = series

    def mutual_info(self, triangle=True):
        """
        Calculate the normalized mutual information matrix
        :param triangle:
        :param show:
        :return:
        """
        columns = self.df.columns
        n_columns = self.df.shape[1]
        mi = np.zeros((n_columns, n_columns))
        for i in range(n_columns):
            for j in range(n_columns):
                mi[i, j] = self.mi_func(self.df[columns[i]], self.df[columns[j]])
        if triangle:
            mi = np.triu(mi)
            np.fill_diagonal(mi, 0)
        return mi

    def plot_mutual_info(self, mi):
        """
        Plot the mutual info array
        :param mi:
        :return:
        """
        norm = color.Normalize()
        norm.autoscale(np.array([0, 1]))
        plt.figure()
        if self.normalized:
            pcm = plt.imshow(mi, norm=norm, cmap='gray')
        else:
            pcm = plt.imshow(mi)
        plt.colorbar(pcm)

    def specific_mutual_info(self, column, verbose=False, k=100):
        """
        Mutual info of a specific column against all others.
        :param column:
        :param print:
        :param top_k:
        :return:
        """
        columns = self.df.columns
        assert column in columns, 'Column not found'
        n_columns = self.df.shape[1]
        smi = np.zeros((n_columns,))
        for i in range(n_columns):
            smi[i] = self.mi_func(self.df[column], self.df[columns[i]])
        if verbose:
            idx = np.argsort(smi)[::-1]
            for i in range(1, np.min([np.size(smi), k + 1])):
                print('Mutual info between {} and {} is {}'.format(column, columns[idx[i]], smi[idx[i]]))
        return smi

    @staticmethod
    def top_k_index(A, k=3):
        """
        Indicies of largest k elements of a matrix
        :param A:
        :param k:
        :return:
        """
        idx = A.ravel().argsort()[:-k - 1:-1]
        I, J = np.unravel_index(idx, A.shape)
        return [(I[n], J[n]) for n in range(k)]

    def print_most_related(self, k=3):
        """
        Print info on k most related variables
        :param k:
        :return:
        """
        columns = self.df.columns
        mi = self.mutual_info(triangle=True)
        idxs = self.top_k_index(mi, k)
        for idx in idxs:
            print(
                '\nMutual info between\n{} and {} is\n{}'.format(columns[idx[0]], columns[idx[1]], mi[idx[0], idx[1]]))

    def print_protected_relatives(self, protected, k=3):
        """
        Print info on k most related variables to a list of protected variables.
        :param protected:
        :param k:
        :return:
        """
        columns = self.df.columns
        for column in protected:
            assert column in columns, 'Column not found'
            print('\nProtected variable {}'.format(column))
            _ = self.specific_mutual_info(column, verbose=True, k=k)
