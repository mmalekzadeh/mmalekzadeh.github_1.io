Data from:

[german credit data](https://archive.ics.uci.edu/ml/datasets/statlog+(german+credit+data))