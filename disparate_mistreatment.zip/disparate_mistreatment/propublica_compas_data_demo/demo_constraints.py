import os,sys
import numpy as np
from load_compas_data import *
sys.path.insert(0, '../../fair_classification/') # the code for fair classification is in this directory
import utils as ut
import funcs_disp_mist as fdm

###### Peter #########
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
from mutual_info_analyser import MutualInfoAnalyser
###### Peter #########

def train_test_classifier():
    w = fdm.train_model_disp_mist(x_train, y_train, x_control_train, loss_function, EPS, cons_params)
    train_score, test_score, cov_all_train, cov_all_test, s_attr_to_fp_fn_train, s_attr_to_fp_fn_test = fdm.get_clf_stats(w, x_train, y_train, x_control_train, x_test, y_test, x_control_test, sensitive_attrs)
    # accuracy and FPR are for the test because we need of for plotting
    return w, test_score, s_attr_to_fp_fn_test


def plot(acc, major, minor, metric):
    # data to plot
    n_groups = 5
#    major = [90, 55, 40, 65,45]
#    minor = [85, 62, 54, 20,55]
#    acc = [90, 55, 40, 65,45]

    # create plot
    fig, ax = plt.subplots()
    index = np.arange(n_groups)
    bar_width = 0.25
    opacity = 0.8
    
    font = {'family' : 'normal',
        'weight' : 'bold',
        'size'   : 22}

    mpl.rc('font', **font)
    
    rects1 = plt.bar(index, major, bar_width,
                     alpha=opacity,
                     color='g',
                     label='Female')
     
    rects2 = plt.bar(index + bar_width, minor, bar_width,
                     alpha=opacity,
                     color='b',
                     label='Male')
     
    plt.xlabel('Measure:[Overall Accuracy %]', fontsize=20)
    plt.ylabel('Error Rate', fontsize=20)
    plt.title(metric+' : Disparate Mistreatment Calibration', fontsize=20)
    plt.xticks(index + bar_width, ('Orginal:('+str(acc[0])+'%)', 'MisCla:('+str(acc[1])+'%)', 'FPR:('+str(acc[2])+'%)', 'FNR:('+str(acc[3])+'%)', 'FPR+FNR:('+str(acc[4])+'%)'), fontsize=20)
    plt.legend(fontsize=18)
    fig = plt.gcf()
    fig.set_size_inches(18.5, 10.5)
    plt.tight_layout()
    fig.savefig(metric+'.png', dpi=100)
    #plt.show()

	
""" Generate the synthetic data """
data_type = 1

df = pd.read_csv('./data/credit.csv', header=0).iloc[:,1:]
df = df.drop(columns=['marital_sex'])
mia = MutualInfoAnalyser(normalized=True)
mia.add_dataframe(df)
mia.discretize_dataframe(n_bins=5)
german = mia.df
dec = german['decision']
dec[dec == 1] = -1
dec[dec == 0] = 1
X = german[['checking_status','months','credit_history',
            'credit_purpose','credit_amount', 'savings_status',
            'employment_duration','installment_rate', 'guarantors',
            'residence_since', 'property','age',
            'installment_plans', 'housing', 'existing_credits',
            'job','dependants', 'telephone', 'foreign_worker', 'gender']]
X = X.values
X = np.array(X).astype(None)

x_control = {}
protected = np.array(german['gender'])
x_control['race'] = protected

y = np.array(german['decision'])

#
##X, y, x_control = load_compas_data()
#
#prot = 9
#german = np.genfromtxt("german.data-numeric")
#german[german[:,24]==2,24]= -1
#german[german[:,14]==2.,prot]= 0
#y = german[:,24].astype(int)
#X = german[:,:24]
#x_control = {}
#x_control['race'] = X[:,prot]
#x_control['race'][x_control['race'] <= 25]= 0
#x_control['race'][x_control['race'] > 25]= 1
#


sensitive_attrs = x_control.keys()

	
""" Split the data into train and test """
train_fold_size = 0.5
x_train, y_train, x_control_train, x_test, y_test, x_control_test = ut.split_into_train_test(X, y, x_control, train_fold_size)
cons_params = None # constraint parameters, will use them later
loss_function = "logreg" # perform the experiments with logistic regression
EPS = 1e-6		

""" Classify the data while optimizing for accuracy """
acc = np.zeros(5)

majorfpr = np.zeros(5)
majorfnr = np.zeros(5)

minorfpr = np.zeros(5)
minorfnr = np.zeros(5)

print
print "== Unconstrained (original) classifier =="
w_uncons, acc_uncons, s_attr_to_fp_fn_test_uncons = train_test_classifier()
print "\n-----------------------------------------------------------------------------------\n"
acc[0] = acc_uncons
minorfnr[0] = s_attr_to_fp_fn_test_uncons['race'][0]['fnr']
majorfnr[0] = s_attr_to_fp_fn_test_uncons['race'][1]['fnr']

minorfpr[0] = s_attr_to_fp_fn_test_uncons['race'][0]['fpr']
majorfpr[0] = s_attr_to_fp_fn_test_uncons['race'][1]['fpr']

""" Now classify such that we optimize for accuracy while achieving perfect fairness """

""" cons_type == 0: means the whole combined misclassification constraint (without FNR or FPR)
    cons_type == 1: FPR constraint
    cons_type == 2: FNR constraint
    cons_type == 4: both FPR as well as FNR constraints
"""    
	
print
print "\n\n== Constraints on Both FPR and FNR =="	# setting parameter for constraints


for i in range(1,5):
    ct = [0,1,2,4][i-1]
    print(ct)
    cons_type = ct # FPR constraint -- just change the cons_type, the rest of parameters should stay the same
    tau = 5.0
    mu = 1.2
    sensitive_attrs_to_cov_thresh = {"race": {0:{0:0, 1:0}, 1:{0:0, 1:0}, 2:{0:0, 1:0}}} # zero covariance threshold, means try to get the fairest solution
    cons_params = {"cons_type": cons_type, 
    					"tau": tau, 
    					"mu": mu, 
    					"sensitive_attrs_to_cov_thresh": sensitive_attrs_to_cov_thresh}
    
    w_cons, acc_cons, s_attr_to_fp_fn_test_cons  = train_test_classifier()
    
    acc[i] = acc_cons
    minorfnr[i] = s_attr_to_fp_fn_test_cons['race'][0]['fnr']
    majorfnr[i] = s_attr_to_fp_fn_test_cons['race'][1]['fnr']
    
    minorfpr[i] = s_attr_to_fp_fn_test_cons['race'][0]['fpr']
    majorfpr[i] = s_attr_to_fp_fn_test_cons['race'][1]['fpr']

    print "\n-----------------------------------------------------------------------------------\n"

plot(acc, majorfpr, minorfpr, "False Positive Rate")    
#plot(acc, majorfnr, minorfnr, "False Negative Rate")    